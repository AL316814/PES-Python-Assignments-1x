#Create a list with at least 10 elements in it print all elements
myList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print myList
 #perform slicing
slice=myList[2]
print slice
 #perform repetition with * operator
repet=myList * 2
print repet
 #Perform concatenation wiht other list
myList1 = ['Hello', 'World']
myList2 = [1, 4, 9, 16, 25]
myList3 = ['Ten', 20, 'Thirty', 40]
concat = myList1 + myList2 + myList3
print concat
