#10.Using assignment operators, perform following operations Addition, Substation, Multiplication, Division, Modulus, Exponent and Floor division operations
import math
a=3.2
b=4.6
add=a+b
sub=b-a
mul=a*b
div=b/a
mod=a%b
exp1=a**b
flordiv=b//a
print "addition is \n",add
print "subtraction is \n",sub
print "multiplication is \n",mul
print "division is \n",div
print "modulus is \n",mod
print "exponent is \n",exp1
print "floor division is \n",flordiv