myTuple = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
print myTuple
 #perform slicing
slice=myTuple[2]
print slice
 #perform repetition with * operator
repet=myTuple * 2
print repet
 #Perform concatenation wiht other list
myTuple1 = ['Hello', 'World']
myTuple2 = [1, 4, 9, 16, 25]
myTuple3 = ['Ten', 20, 'Thirty', 40]
concat = myTuple1 + myTuple2 + myTuple3
print concat