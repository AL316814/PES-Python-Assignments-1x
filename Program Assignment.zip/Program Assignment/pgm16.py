#Python Numbers
'''
16.i) Check whether given number is prime or not.
ii) Generate all the prime numbers between 1 to N where N is given number.
'''
num=int(input("Enter the number to check for prime"))
if num==1:
  print "Number",num,"is not a prime number"
elif num>1:
  for i in range(2,num):
    if num%i==0:
      print "Number",num," is not a prime number"
      break
  else:
    print "Number",num,"is a prime number"
upper=int(input("Enter the number till which you need to print "))
print "The prime numbers between the given range is"
for num in range(2,upper+1):
  if num>1:
    for i in range(2,num):
      if(num%i)==0:
        break
    else:
      print num