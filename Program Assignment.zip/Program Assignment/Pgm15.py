#Python List functions and Methods
'''15.Create a list of 5 names and check given name exist in the List.
a) Use membership operator ( IN ) to check the presence of an element.
b) Perform above task without using membership operator.
c) Print the elements of the list in reverse direction.'''

#a) Use membership operator ( IN ) to check the presence of an element.
list1=['Joseph','Mathew','Jacob','Dominic','Thomas']
#print list1
if ('Mathew') in list1:
  print"Mathew is present in the list"
else:
  print"Mathew is not present in the list"

#b) Perform above task without using membership operator.
for i in list1:
  if (i=='Mathew'):
    print"Mathew is present in the list"
    break
else:
    print"Mathew is not present in the list"

#c) Print the elements of the list in reverse direction.
list1.reverse()
print"the elements of list1 in reverse direction are",list1
