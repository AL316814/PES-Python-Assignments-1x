#9.Write program to Add , subtract, multiply, divide 2 complex numbers.
import math
a=2+2j
b=3+3j
print "Addition of two complex numbers :",a+b
print "Subtraction of two complex numbers :",a-b
print "Multiplication of two complex numbers :",a*b
print "Division of two complex numbers :",a/b
