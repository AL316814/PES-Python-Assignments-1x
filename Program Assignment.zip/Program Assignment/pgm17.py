#Decision making (IF .. Else structure)
'''17.Write program to find the biggest and Smallest of N numbers.
PS: Use the functions to find biggest and smallest numbers.'''
num=list(input("Enters numbers again"))
biggest=max(num)
smallest=min(num)
print "Maximum is",biggest
print "Minimum is",smallest