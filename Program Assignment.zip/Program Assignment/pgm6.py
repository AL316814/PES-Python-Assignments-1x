  #Slice the string using slice operator [:] slice the portion the strings to create a sub strings
s = 'Hello, How are you!'
firstchar=s[0]
substr1=s[:3]
substr2=s[:4]
substr3=s[:5]
  #Repeat the string 100 times using repeat operator *
newstr = 'Hello'
print newstr[:5]*100
  #Read strig 2 and  concatenate with other string using + operator
str1 ='Hello'
str2 = 'World'
strconcat= str1 + str2
