#1.Write a program to add , Subtract, Multiply, and divide 2 numbers
num1=20
num2=10
Add=num1+num2
Sub=num1-num2
Mul=num1*num2
Div=num1/num2
print "Addition is",Add
print "Subtraction is",Sub
print "Multiplication is",Mul
print "Division is",Div

