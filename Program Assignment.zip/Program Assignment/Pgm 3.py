#Write a program to find  given number is odd or Even
a=int(input("Please Enter a Number : "))
if(a%2==0):
    print("This Number is Even")
else:
    print("This Number is Odd")